from PyQt5.QtCore import QObject, pyqtSignal
import shlex

class AppContext(QObject):
    config_saved = pyqtSignal()
    config_loaded = pyqtSignal()
    config_changed = pyqtSignal()
    qemu_args_pasted = pyqtSignal(list)

    def __init__(self):
        super().__init__()
        self.config = {}
        self.config_modified = False
        self._is_loading = False

    def set_config(self, new_config):
        self.config = new_config
        self.config_loaded.emit()

    def update_config(self, partial_config):
        if self._is_loading:
            return

        modified = False
        for key, value in partial_config.items():
            if self.config.get(key) != value:
                self.config[key] = value
                modified = True

        if modified:
            self.config_changed.emit()
            self.config_modified = True

    def mark_saved(self):
        self.config_saved.emit()
        self.config_modified = False

    def is_modified(self):
        return self.config_modified
        
    def split_shell_command(self, cmdline_str):
        if isinstance(cmdline_str, list):
            cmdline_str = ' '.join(cmdline_str)
        cleaned = cmdline_str.replace("\\\n", " ").replace("\\\r\n", " ").strip()
        # shlex foi movido para o topo do arquivo
        return shlex.split(cleaned)

    def block_all_signals(self, on=True):
        self._blocking_signals = on # Mantém sua lógica original se houver
        pass # Não altera o estado de _is_loading
        
    def start_loading(self):
        """Inicia o modo de carregamento, ignorando update_config e resetando modified flag."""
        self._is_loading = True
        self.config_modified = False # Garante que está False ao iniciar o carregamento

    def finish_loading(self):
        """Finaliza o modo de carregamento e define config_modified para False."""
        self._is_loading = False
        self.config_modified = False # Garante que o estado final é "não modificado"
