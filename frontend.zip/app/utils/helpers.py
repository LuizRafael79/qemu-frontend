# app/utils/helpers.py - funções auxiliares
