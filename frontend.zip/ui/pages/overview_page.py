from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QGroupBox, QFormLayout,
    QComboBox, QLineEdit, QPushButton, QHBoxLayout, QTextEdit, QTabWidget, QFileDialog
)
from PyQt5.QtCore import pyqtSignal, Qt
import os
import re
import subprocess
import shutil

class OverviewPage(QWidget):
    overview_config_changed = pyqtSignal()

    def __init__(self, app_context):
        super().__init__()
        self.app_context = app_context

        self.setup_ui()
        self.populate_qemu_binaries()
        self.bind_signals()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)

        # Título
        self.title_label = QLabel("Virtual Machine Overview")
        self.title_label.setStyleSheet("font-size: 16px; font-weight: bold;")
        main_layout.addWidget(self.title_label)

        # QEMU Executable
        qemu_group = QGroupBox("QEMU Executable")
        qemu_layout = QFormLayout()
        self.qemu_combo = QComboBox()
        qemu_layout.addRow("Available QEMU:", self.qemu_combo)
        qemu_group.setLayout(qemu_layout)
        main_layout.addWidget(qemu_group)

        # Custom Executable
        custom_group = QGroupBox("Custom Executable")
        custom_layout = QHBoxLayout()
        self.custom_path = QLineEdit()
        self.btn_browse = QPushButton("Browse")
        self.btn_clear = QPushButton("Clear")
        custom_layout.addWidget(self.custom_path)
        custom_layout.addWidget(self.btn_browse)
        custom_layout.addWidget(self.btn_clear)
        custom_group.setLayout(custom_layout)
        main_layout.addWidget(custom_group)

        # Arquitetura + 3DFX info
        self.arch_label = QLabel("Architecture:")
        main_layout.addWidget(self.arch_label)

        # Launch Button
        self.btn_launch = QPushButton("Launch QEMU")
        main_layout.addWidget(self.btn_launch)

        # Output tabs
        self.output_tabs = QTabWidget()
        self.qemuargs_output = QTextEdit()
        self.qemuargs_output.setReadOnly(False)
        self.qemuextraargs_output = QTextEdit()
        self.qemuextraargs_output.setReadOnly(False)
        self.console_output = QTextEdit()
        self.console_output.setReadOnly(True)
        self.mesa_output = QTextEdit()
        self.mesa_output.setReadOnly(True)
        self.output_tabs.addTab(self.qemuargs_output, "Qemu Args")
        self.output_tabs.addTab(self.qemuextraargs_output, "Extra Args")
        self.output_tabs.addTab(self.console_output, "Console Output")
        self.output_tabs.addTab(self.mesa_output, "mesaPT / glidePT Logs")
        main_layout.addWidget(self.output_tabs)

        # FPS Label
        self.fps_label = QLabel("FPS: --")
        main_layout.addWidget(self.fps_label)
        
        self.qemuargs_output.textChanged.connect(self._on_args_changed)

    def populate_qemu_binaries(self):
        found = []
        for path in os.environ.get("PATH", "").split(os.pathsep):
            if os.path.isdir(path):
                for f in os.listdir(path):
                    if f.startswith("qemu-system-"):
                        full_path = shutil.which(f)
                        if full_path and full_path not in found:
                            found.append(full_path)
        found = sorted(found)
        self.app_context.qemu_binaries = found
        self.qemu_combo.clear()
        self.qemu_combo.addItems([os.path.basename(p) for p in found])

        # Se houver config, tenta selecionar executável salvo
        selected_bin = self.app_context.config.get("qemu_executable", "")
        if selected_bin and selected_bin in [os.path.basename(p) for p in found]:
            self.qemu_combo.setCurrentText(selected_bin)
            bin_path = found[[os.path.basename(p) for p in found].index(selected_bin)]
        elif found:
            # seleciona o primeiro da lista (padrão)
            self.qemu_combo.setCurrentIndex(0)
            bin_path = found[0]
        else:
            bin_path = None

        # Detecta arquitetura para o executável selecionado (se existir)
        if bin_path:
            self.detect_architecture(bin_path)
        else:
            self.arch_label.setText("Architecture:")

    def bind_signals(self):
        self.qemu_combo.currentIndexChanged.connect(self.on_qemu_combo_changed)
        self.btn_browse.clicked.connect(self.on_browse_clicked)
        self.btn_clear.clicked.connect(self.on_clear_clicked)
        self.custom_path.textChanged.connect(self.on_custom_path_changed)
        self.btn_launch.clicked.connect(self.on_launch_clicked)

    def on_qemu_combo_changed(self, index):
        if 0 <= index < len(self.app_context.qemu_binaries):
            bin_path = self.app_context.qemu_binaries[index]
            self.detect_architecture(bin_path)
            self.app_context.update_config({"qemu_executable": os.path.basename(bin_path)})
            self.overview_config_changed.emit()

    def on_browse_clicked(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select QEMU Executable")
        if path:
            self.custom_path.setText(path)
            self.app_context.update_config({"custom_executable": path})
            self.detect_architecture(path)
            self.overview_config_changed.emit()

    def on_custom_path_changed(self, text):
        self.app_context.update_config({"custom_executable": text})
        if text:
            self.detect_architecture(text)
        self.overview_config_changed.emit()
        
    def on_clear_clicked(self):
        self.custom_path.clear()
        self.app_context.update_config({"custom_executable": ""})

        index = self.qemu_combo.currentIndex()
        if 0 <= index < len(self.app_context.qemu_binaries):
            selected_path = self.app_context.qemu_binaries[index]
        else:
            selected_path = None

        if selected_path:
            self.detect_architecture(selected_path)
        else:
            fallback = "Architecture: No QEMU binary selected"
            self.arch_label.setText(fallback)
            self.app_context.update_config({"architecture": fallback})

        # Sempre marca como modificado e emite sinal
        self.app_context.config_modified = True
        self.app_context.config_changed.emit()
        self.emit_change()
        
    def emit_change(self):
        self.overview_config_changed.emit()

    def detect_architecture(self, binary):
        arch_text = "Unknown"
        git_info = ""
        try:
            basename = os.path.basename(binary)
            match = re.match(r"qemu-system-([a-z0-9_]+)", basename)
            if match:
                arch_text = match.group(1).replace('_', '-')

            result = subprocess.run([binary, "--version"], capture_output=True, text=True, timeout=3)
            output = result.stdout.lower()

            # Detecta 3DFX + commit hash
            for line in output.splitlines():
                if "qemu-3dfx@" in line:
                    git_info = " (3DFX Version - GIT PARSE -> "
                    git_match = re.search(r"qemu-3dfx@([a-f0-9]+)", line)
                    if git_match:
                        git_info += f"{git_match.group(1)[:7]}-)"
                    else:
                        git_info += "unknown)"
                    break
        except Exception:
            pass

        self.arch_label.setText(f"Architecture: {arch_text}{git_info}")
        self.app_context.config["architecture"] = self.arch_label.text()

    def load_config_to_ui(self):
        cfg = self.app_context.config
        if not cfg:
            return

        # Bloqueia sinais dos widgets
        self.qemu_combo.blockSignals(True)
        self.custom_path.blockSignals(True)

        try:
            qemu_exec = cfg.get("qemu_executable", "")
            custom_exec = cfg.get("custom_executable", "")
            arch = cfg.get("architecture", "Architecture: Unknown")
            fps = cfg.get("fps", "FPS: --")

            if qemu_exec and self.qemu_combo.currentText() != qemu_exec:
                self.qemu_combo.setCurrentText(qemu_exec)

            if custom_exec and self.custom_path.text() != custom_exec:
                self.custom_path.setText(custom_exec)

            self.arch_label.setText(arch)
            self.fps_label.setText(fps)
        finally:
            # Restaura sinais
            self.qemu_combo.blockSignals(False)
            self.custom_path.blockSignals(False)

    def on_launch_clicked(self):
        # Exemplo simples, só mostra saída na aba console
        bin_path = self.custom_path.text().strip()
        if not bin_path and self.qemu_combo.currentIndex() >= 0:
            bin_path = self.app_context.qemu_binaries[self.qemu_combo.currentIndex()]

        if not bin_path:
            self.console_output.append("No QEMU binary selected.")
            return

        self.console_output.append(f"Launching: {bin_path}")

        # Apenas exemplo, executar sem argumentos (coloque a lógica real)
        try:
            proc = subprocess.Popen(
                [bin_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            stdout, stderr = proc.communicate(timeout=10)
            self.console_output.append(stdout)
            self.console_output.append(stderr)
        except Exception as e:
            self.console_output.append(f"Failed to launch QEMU: {e}")
            
    def update_qemu_args(self, args_list):
        formatted_command = " ".join(args_list)
        pretty_command = re.sub(r' -', ' \\\n-', formatted_command)
        self.qemuargs_output.blockSignals(True)
        self.qemuargs_output.setPlainText(pretty_command)
        self.qemuargs_output.blockSignals(False)
        
    def _on_args_changed(self):
        raw = self.qemuargs_output.toPlainText()
        if not any(kw in raw for kw in ("-drive", "-device", "-cpu", "-m", "-smp")):
            return  # Ignora textos irrelevantes

        try:
            import shlex
            cmd_clean = raw.replace("\\\n", " ").replace("\n", " ")
            args = shlex.split(cmd_clean)
        except Exception as e:
            print(f"Erro ao fazer parse da linha de comando: {e}")
            return

        self.app_context.qemu_args_pasted.emit(args)


